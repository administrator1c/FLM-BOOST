package com.flmboost.lagfix

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.StatFs
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 8, 18)
    private val panel = Color.rgb(17, 20, 38)
    private val cyan = Color.rgb(0, 229, 255)
    private val violet = Color.rgb(173, 93, 255)
    private val white = Color.rgb(240, 244, 255)
    private val muted = Color.rgb(148, 160, 188)
    private lateinit var ramValue: TextView
    private lateinit var storageValue: TextView
    private lateinit var thermalValue: TextView
    private lateinit var healthValue: TextView
    private lateinit var tipsValue: TextView
    private var profile = "BALANCED"
    private val handler = Handler(Looper.getMainLooper())
    private val refreshTask = object : Runnable {
        override fun run() {
            refreshDeviceStats()
            handler.postDelayed(this, 4000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(txt("FLM BOOST  /  DEVICE OPTIMIZER", 12, cyan, true))
        root.addView(txt("LAG FIX", 34, white, true))
        root.addView(txt("GIẢM GIẬT • ỔN ĐỊNH AUDIO • ANDROID", 10, muted, true))
        root.addView(gap(18))

        val monitor = card()
        monitor.addView(txt("LIVE DEVICE MONITOR", 12, cyan, true))
        healthValue = txt("ĐANG PHÂN TÍCH...", 23, white, true)
        monitor.addView(healthValue)
        ramValue = txt("RAM: --", 13, white, false)
        monitor.addView(ramValue)
        storageValue = txt("BỘ NHỚ TRỐNG: --", 13, white, false)
        monitor.addView(storageValue)
        thermalValue = txt("NHIỆT ĐỘ: --", 13, white, false)
        monitor.addView(thermalValue)
        monitor.addView(txt("Dữ liệu hệ thống cập nhật mỗi 4 giây.", 10, muted, false))
        root.addView(monitor)
        root.addView(gap(12))

        val profiles = card()
        profiles.addView(txt("OPTIMIZATION PROFILE", 12, violet, true))
        profiles.addView(txt("Chọn mức khuyến nghị cho phiên làm nhạc.", 12, muted, false))
        profiles.addView(btn("LOW LOAD  ·  ƯU TIÊN ỔN ĐỊNH", cyan) { chooseProfile("LOW LOAD") })
        profiles.addView(btn("BALANCED  ·  CÂN BẰNG", violet) { chooseProfile("BALANCED") })
        profiles.addView(btn("PERFORMANCE  ·  HIỆU NĂNG", cyan) { chooseProfile("PERFORMANCE") })
        root.addView(profiles)
        root.addView(gap(12))

        val actions = card()
        actions.addView(txt("QUICK OPTIMIZATION", 12, cyan, true))
        actions.addView(txt("Các nút dưới đây mở cài đặt Android để bạn tự điều chỉnh. FLM BOOST không tự ý thay đổi hệ thống.", 12, muted, false))
        actions.addView(btn("MỞ CÀI ĐẶT PIN / HIỆU NĂNG", cyan) { openBatterySettings() })
        actions.addView(btn("MỞ CÀI ĐẶT ỨNG DỤNG FL STUDIO", violet) { openFlmAppSettings() })
        actions.addView(btn("MỞ FL STUDIO MOBILE", cyan) { launchFlm() })
        root.addView(actions)
        root.addView(gap(12))

        val audio = card()
        audio.addView(txt("AUDIO LAG FIX CHECKLIST", 12, violet, true))
        tipsValue = txt(profileTips(), 13, white, false)
        audio.addView(tipsValue)
        root.addView(audio)
        root.addView(gap(12))

        val note = card()
        note.addView(txt("GIỚI HẠN ANDROID", 12, cyan, true))
        note.addView(txt(
            "Android không cho ứng dụng thông thường tự giải phóng RAM của FL Studio Mobile, ép xung CPU/GPU hoặc can thiệp buffer âm thanh của ứng dụng khác. Vì vậy app này giám sát tài nguyên, phát hiện dấu hiệu thiếu bộ nhớ/nóng máy và đưa bạn tới đúng khu vực cài đặt để tối ưu an toàn. Không có cam kết tăng FPS hoặc giảm latency trên mọi máy.",
            12, muted, false
        ))
        root.addView(note)

        refreshDeviceStats()
        handler.postDelayed(refreshTask, 4000)
    }

    private fun chooseProfile(value: String) {
        profile = value
        tipsValue.text = profileTips()
        Toast.makeText(this, "Đã chọn preset $value", Toast.LENGTH_SHORT).show()
    }

    private fun profileTips(): String = when (profile) {
        "LOW LOAD" -> "1. Đóng game/app nặng trước khi mở FL Studio Mobile.\n2. Tắt plugin/FX không dùng và giảm số track đang phát.\n3. Dùng project nhẹ, tránh sample quá lớn.\n4. Nếu có tiếng crackle, tăng audio buffer trong FL Studio Mobile nếu phiên bản hỗ trợ."
        "PERFORMANCE" -> "1. Bật chế độ hiệu năng trong cài đặt pin nếu điện thoại có.\n2. Tránh vừa sạc vừa chạy project nặng nếu máy nóng.\n3. Dùng tai nghe có dây để tránh độ trễ Bluetooth.\n4. Đóng ứng dụng nền và giữ bộ nhớ trong còn trống."
        else -> "1. Khởi động lại máy nếu RAM khả dụng thường xuyên thấp.\n2. Đóng ứng dụng nền không cần thiết.\n3. Dùng tai nghe có dây để giảm độ trễ.\n4. Giảm plugin/FX hoặc tăng buffer nếu xuất hiện tiếng rè."
    }

    private fun refreshDeviceStats() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mem)
        val totalMb = mem.totalMem / (1024L * 1024L)
        val availMb = mem.availMem / (1024L * 1024L)
        val usedPct = if (totalMb > 0) ((totalMb - availMb) * 100 / totalMb).toInt() else 0
        ramValue.text = "RAM khả dụng: ${availMb} MB / ${totalMb} MB  ·  Đang dùng ~${usedPct}%"

        try {
            val stat = StatFs(filesDir.absolutePath)
            val freeMb = stat.availableBytes / (1024L * 1024L)
            storageValue.text = "BỘ NHỚ TRỐNG (phân vùng app): ${freeMb} MB"
        } catch (_: Exception) {
            storageValue.text = "BỘ NHỚ TRỐNG: Không đọc được"
        }

        val thermal = if (Build.VERSION.SDK_INT >= 29) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "Bình thường"
                PowerManager.THERMAL_STATUS_LIGHT -> "Hơi ấm"
                PowerManager.THERMAL_STATUS_MODERATE -> "Ấm"
                PowerManager.THERMAL_STATUS_SEVERE -> "Nóng"
                PowerManager.THERMAL_STATUS_CRITICAL -> "Rất nóng"
                PowerManager.THERMAL_STATUS_EMERGENCY -> "Nguy hiểm"
                PowerManager.THERMAL_STATUS_SHUTDOWN -> "Quá nhiệt"
                else -> "Không rõ"
            }
        } else "Không hỗ trợ trên Android này"
        thermalValue.text = "NHIỆT ĐỘ / THERMAL: $thermal"

        val warning = mem.lowMemory || usedPct >= 88 || thermal.contains("Nóng") || thermal.contains("nguy hiểm") || thermal.contains("Quá nhiệt")
        healthValue.text = if (warning) "CẦN GIẢM TẢI" else "THIẾT BỊ SẴN SÀNG"
        healthValue.setTextColor(if (warning) Color.rgb(255, 166, 70) else cyan)
    }

    private fun openBatterySettings() {
        try {
            startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun openFlmAppSettings() {
        val pkg = findFlmPackage()
        if (pkg == null) {
            Toast.makeText(this, "Chưa tìm thấy FL Studio Mobile trên thiết bị.", Toast.LENGTH_LONG).show()
            return
        }
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
    }

    private fun launchFlm() {
        val pkg = findFlmPackage()
        if (pkg == null) {
            Toast.makeText(this, "Không tìm thấy FL Studio Mobile. Hãy cài ứng dụng trước.", Toast.LENGTH_LONG).show()
            return
        }
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) startActivity(launch)
        else Toast.makeText(this, "Không mở được FL Studio Mobile.", Toast.LENGTH_SHORT).show()
    }

    private fun findFlmPackage(): String? {
        // Package ID commonly used by FL Studio Mobile on Android.
        val candidates = listOf("com.imageline.FLM")
        return candidates.firstOrNull { packageManager.getLaunchIntentForPackage(it) != null }
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(15), dp(15), dp(15))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(panel); cornerRadius = dp(17).toFloat()
            setStroke(dp(1), Color.rgb(43, 51, 82))
        }
    }

    private fun txt(s: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(color)
        typeface = if (bold) Typeface.create("sans-serif", Typeface.BOLD) else Typeface.create("sans-serif", Typeface.NORMAL)
        setPadding(0, dp(3), 0, dp(7))
    }

    private fun btn(s: String, accent: Int, action: () -> Unit) = Button(this).apply {
        text = s; textSize = 11f; isAllCaps = false; setTextColor(white)
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.rgb(26, 31, 55)); cornerRadius = dp(12).toFloat()
            setStroke(dp(1), accent)
        }
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(7) }
    }

    private fun gap(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        handler.removeCallbacks(refreshTask)
        super.onDestroy()
    }
}
