# FLM BOOST Lag Fix 3.0 — Android 11+

Minimum Android 11 (API 30), compile/target SDK 35. Future Android versions, including Android 19, cannot be certified without platform SDKs and device tests.

## Build on GitHub
Upload this ZIP to the repository root, and place the accompanying `build.yml` in `.github/workflows/build.yml`. Run workflow and download the APK artifact.

## Important
This is an Android monitoring and guidance utility, not a tool that can directly modify FL Studio Mobile internals, clear another app's RAM, or guarantee lag elimination. Java and Kotlin both target JVM 17. Build not executed in this environment.
