# FLM BOOST Lag Fix 3.0 — Hướng dẫn chi tiết

## Nội dung
- app/src/main/java/com/flmboost/lagfix/MainActivity.kt: giao diện và các chức năng hỗ trợ
- app/src/main/AndroidManifest.xml: khai báo ứng dụng, hiển thị FL Studio Mobile
- app/src/main/res/values/styles.xml: giao diện
- app/build.gradle.kts: Android minSdk 30, targetSdk 35, Java/Kotlin 17
- build.gradle.kts, settings.gradle.kts, gradle.properties: cấu hình Gradle
- .github/workflows/build.yml: tự build APK trên GitHub

## Build từ điện thoại
1. Tải ZIP FLM_BOOST_FULL_CHI_TIET_Android11_PLUS.zip.
2. Upload ZIP vào thư mục gốc repository GitHub, không cần giải nén.
3. Trong GitHub, tạo hoặc sửa file `.github/workflows/build.yml` và dán nội dung của file `FLM_BOOST_FULL_build.yml` tải riêng.
4. Commit changes, vào Actions > Build FLM BOOST APK > Run workflow.
5. Khi thành công, mở Summary > Artifacts > FLM-BOOST-Android11-Plus-APK; tải ZIP artifact và giải nén để lấy APK.
6. Nếu lỗi, tải artifact FLM-BOOST-Build-Logs và gửi lại để xác định lỗi gốc.

## Giới hạn
Android 11+ (minSdk 30). Android 19 chưa có môi trường xác minh tương thích. Không thể cam kết hết lag hoặc không lỗi trên mọi máy. Chưa chạy build hoặc thử trên thiết bị thực.
